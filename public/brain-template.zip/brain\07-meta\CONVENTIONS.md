---
type: conventions
version: 1
status: active
---
# Conventions

Formats, ID rules, and thresholds are defined here only. Other files cite CV-nn.

## Rules
- **CV-01** IDs are `<PREFIX>-nn` (two digits, three after 99). Never reused. Retired items stay with `status: retired`.
- **CV-02** Rule line grammar, one line, fields separated by ` | `:
  `- **ID** WHEN <trigger> → DO <action> | why: <reason> | breaks: <condition> | conf: <1–5> | ev: <S-nn, A-nn> | status: <candidate|active|superseded|retired> #tag ^block-id`
  `conf`, `ev`, `status` are required; other fields optional. Red flags use `SIGNAL → MEANS → DEFAULT` plus `dom:`. Patterns use `SITUATION → PLAY` plus `dom:`. Principles (`OP`) and taste (`TA`) are free sentences.
- **CV-03** A rule is `active` only with a trigger, an action, and evidence meeting the confidence table below (conf ≥ 3). Lower-confidence lines stay `candidate` in `06-raw/inbox.md`. Only the human promotes. `OP` and `TA` lines are declarations: active when the owner writes them, at any conf.
- **CV-04** Every file has `type`, `version`, `status` (`empty` placeholder · `draft` · `active`). A domain file becomes `active` at ≥ 3 active rules. Sessions follow `05-elicitation/sessions/_TEMPLATE.md`.
- **CV-05** Contradictions: mark the older rule `superseded` with `superseded-by: <ID>`, open an X-nn in GAP-FINDER, never delete.
- **CV-06** Edits: typo or format → nothing. New evidence → update `ev` and `conf`. Changed trigger or action → new ID, old one superseded. Meaning changes bump the file `version`.
- **CV-07** Prefixes come from the registry below. A new domain prefix is taken from the free pool and registered here first.
- **CV-08** Links: wikilinks (`[[S-03]]`); session files are named `S-nn.md`; every rule line ends with a lowercase block ID (`^cs-01`) so `[[cybersec#^cs-01]]` resolves.
- **CV-09** Privacy: no credentials, client-confidential data, or third parties' personal data in the vault. Sanitize artifacts before mining.

## Confidence scale (CV-03)
| conf | Meaning | Evidence required |
|---|---|---|
| 1 | guess | one mention |
| 2 | reasoned | one session answer or artifact, with the owner's reason |
| 3 | demonstrated | ≥ 2 independent items (different sessions or artifacts, different contexts) |
| 4 | bounded | ≥ 3 items, one stating when it fails (`breaks:`) |
| 5 | proven | survived a Belief Audit (type C) and one real project outcome |

## Prefix registry (CV-07)
| Group | Prefixes |
|---|---|
| Reserved by the agent suite (never domains) | PM UX GR SD IR DB SEC |
| Vault rule files | BN (brain agent) · EP (elicitation) · TE (test examiner) · CV (conventions) · SP (sync) · AA (archaeology) |
| Content IDs | H heuristic · RF red flag · P pattern · M model · OP principle · TA taste · Q question · S session · A artifact · X contradiction · CAND candidate · TS tacit signal · PB probe · LN lens |
| Scenario IDs | FL flash · FH flaw hunt · CW compliant-but-wrong · RK rank · PRE pre-mortem |
| Test modules / launchers | T0–T10 · L-01… |
| Domains in use | CS cybersec · SO solutions · BA business analysis |
| Domain free pool | DA data · AR architecture · GC governance/compliance · PV privacy · DV devops · ML AI/ML |
