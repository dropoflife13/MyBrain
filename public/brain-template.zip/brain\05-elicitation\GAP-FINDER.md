﻿---
type: gap-finder
version: 2
status: active
---
# Gap Finder (Unassessed Vault)

Run weekly (launcher L-05). Owns coverage scoring, Self-Map deltas, next-session choice, and the contradiction queue.

## Coverage matrix
| Domain | Active rules | Red flags | Patterns | Avg conf | Status |
|---|---|---|---|---|---|
| cybersec (CS) | 0 | 0 | 0 | â€“ | thin |
| solutions (SO) | 0 | 0 | 0 | â€“ | thin |
| business-analysis (BA) | 0 | 0 | 0 | â€“ | thin |
| ui-frontend (UI) | 0 | 0 | 0 | â€“ | thin |
| cross (H) | 0 | 0 | 0 | â€“ | thin |

Thresholds: **thin** < 5 active rules or avg conf < 3 Â· **ok** 5â€“12 rules and avg â‰¥ 3 Â· **rich** > 12 rules, avg â‰¥ 4, â‰¥ 2 red flags.

## Self-Map deltas
Hidden strength: Demonstrated âˆ’ Self â‰¥ 2. Paper strength: Self âˆ’ Demonstrated â‰¥ 2.
| Domain | Area | Self | Demonstrated | Kind |
|---|---|---|---|---|

## Next session proposal
1. Fill `01-identity/ABOUT-ME.md` (or run Launcher L-09).
2. Run Launcher L-01 (`05-elicitation/THE-TEST.md`) to establish your baseline Self-Map and excavate your first rules.
3. Log your session as `05-elicitation/sessions/S-01.md`.

## Contradiction queue
Format: `- **X-nn** <rule A> vs <rule B>: <conflict> | opened: S-nn | status: open|resolved`
Resolve only in a type C session (EP-03).
_None yet._
