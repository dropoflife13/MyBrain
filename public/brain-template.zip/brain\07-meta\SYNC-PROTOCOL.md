---
type: sync
version: 1
status: active
---
# Sync Protocol — Brain ↔ Project Agents

## Rules
- **SP-01** Project → Brain flows only through `06-raw/inbox.md`. Never edit registries from a project PR.
- **SP-02** Brain → Project is advisory: Tier 0 (plus Tier 1 per task) loads as context; brain rules never override an agent Gate ID.
- **SP-03** Brain rule vs agent rule conflict → escalate to the human. If the brain rule should win, record a waiver in the project (PM-12) citing the brain ID.
- **SP-04** Each project uses one link mechanism (below).
- **SP-05** Only Tier 0/1 files leave the vault (BN-09). Sessions, raw, and inbox never enter a project.
- **SP-06** Weekly loop: ingest inbox → run GAP-FINDER → schedule one session → promote candidates → refresh DIGEST (launchers L-05, L-06, L-07).

## Project → Brain triggers
- An agent Gate FAILs and the fix reveals a judgment → candidate `H-` or domain rule.
- A design decision is reversed → schedule a B session on it.
- A red flag fires in review → candidate `RF-`.
- A waiver is granted against a brain rule → open an X-nn.
- The same Insight is accepted three times → candidate pattern.

## Link mechanisms (SP-04)
- **Paste:** attach `07-meta/DIGEST.md` and the domain file to the session.
- **Claude Code:** in the project `CLAUDE.md` (replace the path with your vault location):
  ```
  ## Brain context (advisory, SP-02)
  @~/brain/07-meta/DIGEST.md
  @~/brain/02-domains/cybersec.md
  ```
- **Claude Project:** upload the same two files as project knowledge.
