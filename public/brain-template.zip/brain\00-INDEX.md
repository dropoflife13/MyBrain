﻿---
type: index
version: 2
status: active
---
# Brain â€” Index (Blank-Slate Fork Template)

A procedural vault: it stores *how you decide*, not only what you know. Rules are single lines with IDs; AI loads by tier.
**This vault starts at 0 personal rules (`status: empty` / `draft`). You must assess yourself to earn every rule.**

## Loading Tiers (for AI)
| Tier | When | Files |
|---|---|---|
| 0 | always | `07-meta/DIGEST.md` (fallback `01-identity/OPERATING-PRINCIPLES.md`) + `04-agents/INDEX.md` |
| 1 | by task domain | `02-domains/<domain>.md` + matching `04-agents/<agent>.md` |
| 2 | on judgment calls | `03-heuristics/*`, `04-models/*`, `01-identity/TASTE.md` |
| 3 | only when asked | `05-elicitation/sessions/`, `06-raw/` |

Files with `status: empty` or `draft` are skipped; only `status: active` lines count as rules (BN-05).

## Start here (Self-Assessment Flow)
0. Fill `01-identity/ABOUT-ME.md`: form, essay, or AI interview (launcher L-09 in `05-elicitation/LAUNCHERS.md`).
1. Fill `01-identity/OPERATING-PRINCIPLES.md` (10 minutes, one sentence per line).
2. Run the diagnostic self-assessment: launcher L-01 in `05-elicitation/LAUNCHERS.md` or `05-elicitation/THE-TEST.md` (Self-Map + 3 Fast Excavation Micro-Triggers).
3. Review `06-raw/inbox.md`; promote validated rules (`conf >= 3` with `breaks:` condition) using launcher L-06 (CV-03).
4. Generate your executive `07-meta/DIGEST.md` via launcher L-07 once your rules are active.

## Domain Map (Unassessed â€” 0 Active Rules)
| Domain | Prefix | File | Active rules | Avg conf | Coverage |
|---|---|---|---|---|---|
| Cybersecurity | CS | [[cybersec]] | 0 | â€“ | thin |
| Solutions | SO | [[solutions]] | 0 | â€“ | thin |
| Business Analysis | BA | [[business-analysis]] | 0 | â€“ | thin |
| UI & Frontend | UI | [[ui-frontend]] | 0 | â€“ | thin |

Counts are refreshed by GAP-FINDER. Add a domain: see [[EXTENDING]].

## Folders
- `01-identity/` who you are as a practitioner (`status: empty` until assessed)
- `02-domains/` per-specialty rules (`status: draft` until assessed)
- `03-heuristics/` cross-domain judgment, red flags, patterns (`status: empty` until assessed)
- `04-agents/` the 7 Core Execution Gatekeepers (`DB`, `SEC`, `UX`, `PM`, `SD`, `IR`, `GR`)
- `04-models/` mental models, one per file
- `05-elicitation/` diagnostic tests (`THE-TEST.md`), launchers (`LAUNCHERS.md`), scenarios, gap tracking
- `06-raw/` unprocessed candidate rules (`inbox.md`)
- `07-meta/` conventions, sync, extending, digest, brain agent
