---
type: protocol
version: 1
status: active
---
# Artifact Archaeology

Mines habits from work already made: specs, diagrams, code structure, prompts, agent files, proposals, commit messages. Output: candidates with pointers. Session type F.

## Rules
- **AA-01** Register every artifact below as A-nn before mining. Sanitize first (CV-09).
- **AA-02** Every observation cites a location (file, section, line).
- **AA-03** One artifact yields conf ≤ 2; a candidate needs ≥ 2 independent artifacts for conf 3 (CV-03).
- **AA-04** Describe what is there; never infer motive. Motive comes from asking the owner.
- **AA-05** Present each candidate as a question: "I see X in A-01 and A-03. Is that a rule? When does it break?"

## Lenses
| ID | Lens | Look for |
|---|---|---|
| LN-1 | Repetition | the same choice in ≥ 2 artifacts |
| LN-2 | Absence | something consistently missing |
| LN-3 | Constraint | limits added unprompted (size caps, ordering, ownership) |
| LN-4 | Order | what comes first and last |
| LN-5 | Correction | diffs between versions: what changed |
| LN-6 | Rejection | what was removed or refused |
| LN-7 | Pre-emption | objections answered before anyone asked |
| LN-8 | Naming | naming and structure conventions |

## Procedure
1. Register the artifact (table below).
2. Read it once per lens; list observations with locations (AA-02).
3. Group observations across artifacts; discard singletons from conf 3 (AA-03).
4. Draft each group as WHEN → DO with its evidence.
5. Ask the owner the AA-05 question for each; record the answer verbatim in the session file.
6. Append surviving candidates to `06-raw/inbox.md`.

## Artifact registry
| ID | Type | Location | Date | Sanitized |
|---|---|---|---|---|
| A-01 | prompt: seven-agent suite brief | chat transcript | 2026-10-25 | yes |

Worked example: A-01 yielded CAND-01…CAND-07 in `06-raw/inbox.md` (LN-1 ownership and ID habits, LN-3 the 80-line cap, LN-7 defense pre-emption).
